A bank to test with.
